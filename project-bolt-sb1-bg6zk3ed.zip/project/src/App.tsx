import React, { useState, useEffect } from 'react';
import { 
  Leaf, 
  CloudRain, 
  Droplets, 
  Upload, 
  AlertTriangle, 
  BarChart3, 
  Camera, 
  Menu, 
  X,
  Home,
  Settings,
  HelpCircle,
  Bell
} from 'lucide-react';
import { fetchSoilData, SoilData, SoilLocation } from './services/soilApi';

// Mock data for demonstration
const mockAlerts = [
  { id: 1, type: 'disease', severity: 'high', message: 'Potential blight detected in north field', date: '2h ago' },
  { id: 2, type: 'weather', severity: 'medium', message: 'Heavy rainfall expected in 48 hours', date: '5h ago' },
  { id: 3, type: 'soil', severity: 'low', message: 'Nitrogen levels below optimal in east field', date: '1d ago' },
];

// Mock weather data as fallback
const mockWeatherData = {
  temperature: 24,
  humidity: 65,
  rainfall: 0,
  forecast: [
    { day: 'Today', temp: 24, icon: 'sun' },
    { day: 'Tomorrow', temp: 22, icon: 'cloud-rain' },
    { day: 'Wed', temp: 20, icon: 'cloud-rain' },
    { day: 'Thu', temp: 23, icon: 'cloud' },
    { day: 'Fri', temp: 25, icon: 'sun' }
  ]
};

const API_KEY = '337e822ad82ee3693661794c6ca440b2';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<null | {
    disease: string;
    confidence: number;
    recommendations: string[];
  }>(null);
  const [weatherData, setWeatherData] = useState<any>(null);
  const [weatherError, setWeatherError] = useState<string | null>(null);
  const [location, setLocation] = useState<SoilLocation | null>(null);
  const [formattedForecast, setFormattedForecast] = useState<any[]>([]);
  const [soilData, setSoilData] = useState<SoilData | null>(null);
  const [soilError, setSoilError] = useState<string | null>(null);
  const [isFetchingSoil, setIsFetchingSoil] = useState<boolean>(false);

  useEffect(() => {
    // Get user's current location
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lon: longitude });
        },
        (error) => {
          console.error('Error getting location:', error);
          setWeatherError('Unable to get your location. Using default weather data.');
          // Use default coordinates if geolocation fails
          setLocation({ lat: 40.7128, lon: -74.0060 }); // New York coordinates as fallback
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
      setWeatherError('Geolocation is not supported by your browser. Using default weather data.');
      // Use default coordinates if geolocation is not supported
      setLocation({ lat: 40.7128, lon: -74.0060 }); // New York coordinates as fallback
    }
  }, []);

  useEffect(() => {
    // Fetch weather and soil data when location is available
    if (location) {
      fetchWeatherData(location.lat, location.lon);
      fetchSoilDataForLocation(location);
    }
  }, [location]);

  // Process weather data into a 5-day forecast format
  useEffect(() => {
    if (weatherData && weatherData.list) {
      const processedForecast = processForecastData(weatherData.list);
      setFormattedForecast(processedForecast);
    }
  }, [weatherData]);

  const fetchSoilDataForLocation = async (location: SoilLocation) => {
    try {
      setIsFetchingSoil(true);
      const data = await fetchSoilData(location);
      setSoilData(data);
      setSoilError(null);
    } catch (error) {
      console.error('Error in soil data fetch:', error);
      setSoilError('Failed to fetch soil data. Using default soil information.');
    } finally {
      setIsFetchingSoil(false);
    }
  };

  const processForecastData = (forecastList: any[]) => {
    // Group forecast data by day
    const dailyData: Record<string, any[]> = {};
    
    forecastList.forEach(item => {
      const date = new Date(item.dt * 1000);
      const day = date.toLocaleDateString('en-US', { weekday: 'short' });
      
      if (!dailyData[day]) {
        dailyData[day] = [];
      }
      
      dailyData[day].push(item);
    });
    
    // Get average data for each day
    const processedForecast = Object.keys(dailyData).map(day => {
      const dayData = dailyData[day];
      const avgTemp = dayData.reduce((sum, item) => sum + item.main.temp, 0) / dayData.length;
      
      // Determine most common weather condition
      const weatherCounts: Record<string, number> = {};
      dayData.forEach(item => {
        const condition = item.weather[0].main;
        weatherCounts[condition] = (weatherCounts[condition] || 0) + 1;
      });
      
      let dominantWeather = '';
      let maxCount = 0;
      
      Object.keys(weatherCounts).forEach(condition => {
        if (weatherCounts[condition] > maxCount) {
          maxCount = weatherCounts[condition];
          dominantWeather = condition;
        }
      });
      
      // Map weather condition to icon
      let icon = 'sun';
      if (dominantWeather.includes('Rain') || dominantWeather.includes('Drizzle')) {
        icon = 'cloud-rain';
      } else if (dominantWeather.includes('Cloud')) {
        icon = 'cloud';
      }
      
      return {
        day,
        temp: Math.round(avgTemp),
        icon,
        condition: dominantWeather
      };
    });
    
    // Limit to 5 days
    return processedForecast.slice(0, 5);
  };

  const fetchWeatherData = async (lat: number, lon: number) => {
    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`
      );
      
      if (!response.ok) {
        throw new Error(`Weather API error: ${response.status}`);
      }
      
      const data = await response.json();
      setWeatherData(data);
      setWeatherError(null);
    } catch (error) {
      console.error('Error fetching weather data:', error);
      setWeatherError('Failed to fetch weather data. Using default weather information.');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = () => {
    if (!selectedImage) return;
    
    setIsAnalyzing(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      setAnalysisResult({
        disease: 'Late Blight',
        confidence: 92.5,
        recommendations: [
          'Apply copper-based fungicide within 24 hours',
          'Ensure proper ventilation between plants',
          'Remove and destroy infected leaves'
        ]
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  const resetAnalysis = () => {
    setSelectedImage(null);
    setAnalysisResult(null);
  };

  const getWeatherIcon = (iconCode: string) => {
    return `http://openweathermap.org/img/wn/${iconCode}@2x.png`;
  };

  // Get current weather data from the first forecast item
  const getCurrentWeather = () => {
    if (weatherData && weatherData.list && weatherData.list.length > 0) {
      return {
        temp: Math.round(weatherData.list[0].main.temp),
        humidity: weatherData.list[0].main.humidity,
        wind: Math.round(weatherData.list[0].wind.speed),
        description: weatherData.list[0].weather[0].description,
        icon: weatherData.list[0].weather[0].icon
      };
    }
    return null;
  };

  const currentWeather = getCurrentWeather();

  // Function to refresh soil data
  const refreshSoilData = () => {
    if (location) {
      fetchSoilDataForLocation(location);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar - Desktop */}
      <div className="hidden md:flex md:flex-col md:w-64 bg-white shadow-md">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <Leaf className="h-8 w-8 text-green-600" />
            <h1 className="text-xl font-bold text-gray-800">Good To Grow</h1>
          </div>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            <li>
              <button 
                onClick={() => setActiveTab('dashboard')}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'dashboard' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <Home className="h-5 w-5" />
                <span>Dashboard</span>
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('disease')}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'disease' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <Leaf className="h-5 w-5" />
                <span>Disease Detection</span>
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('soil')}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'soil' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <Droplets className="h-5 w-5" />
                <span>Soil Analysis</span>
              </button>
            </li>
            <li>
              <button 
                onClick={() => setActiveTab('weather')}
                className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'weather' ? 'bg-green-50 text-green-600' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <CloudRain className="h-5 w-5" />
                <span>Weather Forecast</span>
              </button>
            </li>
          </ul>
          <div className="mt-8 pt-4 border-t border-gray-200">
            <ul className="space-y-2">
              <li>
                <button className="w-full flex items-center space-x-3 p-3 rounded-lg text-gray-700 hover:bg-gray-100">
                  <Settings className="h-5 w-5" />
                  <span>Settings</span>
                </button>
              </li>
              <li>
                <button className="w-full flex items-center space-x-3 p-3 rounded-lg text-gray-700 hover:bg-gray-100">
                  <HelpCircle className="h-5 w-5" />
                  <span>Help & Support</span>
                </button>
              </li>
            </ul>
          </div>
        </nav>
      </div>

      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white z-10 flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <Leaf className="h-6 w-6 text-green-600" />
          <h1 className="text-lg font-bold text-gray-800">Good To Grow</h1>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-md text-gray-500 hover:text-gray-600 hover:bg-gray-100"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-20 bg-white pt-16">
          <nav className="p-4">
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => {
                    setActiveTab('dashboard');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'dashboard' ? 'bg-green-50 text-green-600' : 'text-gray-700'}`}
                >
                  <Home className="h-5 w-5" />
                  <span>Dashboard</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    setActiveTab('disease');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'disease' ? 'bg-green-50 text-green-600' : 'text-gray-700'}`}
                >
                  <Leaf className="h-5 w-5" />
                  <span>Disease Detection</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    setActiveTab('soil');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'soil' ? 'bg-green-50 text-green-600' : 'text-gray-700'}`}
                >
                  <Droplets className="h-5 w-5" />
                  <span>Soil Analysis</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => {
                    setActiveTab('weather');
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center space-x-3 p-3 rounded-lg ${activeTab === 'weather' ? 'bg-green-50 text-green-600' : 'text-gray-700'}`}
                >
                  <CloudRain className="h-5 w-5" />
                  <span>Weather Forecast</span>
                </button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 md:ml-64 pt-4 md:pt-0">
        <main className="p-4 md:p-6 mt-14 md:mt-0">
          {/* Dashboard */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-800">Farm Dashboard</h2>
                <div className="flex items-center space-x-2">
                  <button className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200">
                    <Bell className="h-5 w-5" />
                  </button>
                </div>
              </div>

              {/* Alert Section */}
              <div className="bg-white rounded-lg shadow-sm p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Recent Alerts</h3>
                  <button className="text-sm text-green-600 hover:text-green-700">View All</button>
                </div>
                <div className="space-y-3">
                  {mockAlerts.map(alert => (
                    <div key={alert.id} className={`p-3 rounded-lg border-l-4 ${
                      alert.severity === 'high' ? 'border-red-500 bg-red-50' : 
                      alert.severity === 'medium' ? 'border-yellow-500 bg-yellow-50' : 
                      'border-blue-500 bg-blue-50'
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <AlertTriangle className={`h-5 w-5 mt-0.5 ${
                            alert.severity === 'high' ? 'text-red-500' : 
                            alert.severity === 'medium' ? 'text-yellow-500' : 
                            'text-blue-500'
                          }`} />
                          <div>
                            <p className="text-gray-800 font-medium">{alert.message}</p>
                            <p className="text-xs text-gray-500">{alert.date}</p>
                          </div>
                        </div>
                        <button className="text-gray-400 hover:text-gray-600">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Weather Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Current Weather</h3>
                    <CloudRain className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      {currentWeather ? (
                        <>
                          <p className="text-3xl font-bold text-gray-800">{currentWeather.temp}°C</p>
                          <p className="text-sm text-gray-500">Humidity: {currentWeather.humidity}%</p>
                        </>
                      ) : weatherError ? (
                        <>
                          <p className="text-3xl font-bold text-gray-800">{mockWeatherData.temperature}°C</p>
                          <p className="text-sm text-gray-500">Humidity: {mockWeatherData.humidity}%</p>
                        </>
                      ) : (
                        <p className="text-xl font-medium text-gray-500">Loading...</p>
                      )}
                    </div>
                    <button 
                      onClick={() => setActiveTab('weather')}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Details
                    </button>
                  </div>
                </div>

                {/* Soil Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Soil Health</h3>
                    <Droplets className="h-5 w-5 text-green-500" />
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      {soilData ? (
                        <>
                          <p className="text-3xl font-bold text-gray-800">pH {soilData.ph}</p>
                          <p className="text-sm text-gray-500">Moisture: {soilData.moisture}%</p>
                        </>
                      ) : isFetchingSoil ? (
                        <p className="text-xl font-medium text-gray-500">Loading...</p>
                      ) : (
                        <>
                          <p className="text-3xl font-bold text-gray-800">pH 6.5</p>
                          <p className="text-sm text-gray-500">Moisture: 42%</p>
                        </>
                      )}
                    </div>
                    <button 
                      onClick={() => setActiveTab('soil')}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Details
                    </button>
                  </div>
                </div>

                {/* Crop Health Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Crop Health</h3>
                    <Leaf className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-3xl font-bold text-gray-800">Good</p>
                      <p className="text-sm text-gray-500">Last scan: 2 days ago</p>
                    </div>
                    <button 
                      onClick={() => setActiveTab('disease')}
                      className="text-sm text-green-600 hover:text-green-700"
                    >
                      Scan Now
                    </button>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-white rounded-lg shadow-sm p-4">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">AI Recommendations</h3>
                <ul className="space-y-3">
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <CloudRain className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Delay irrigation for 48 hours</p>
                      <p className="text-sm text-gray-600">Heavy rainfall is expected. Save water and prevent waterlogging.</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                      <Droplets className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Apply nitrogen-rich fertilizer</p>
                      <p className="text-sm text-gray-600">Soil analysis shows nitrogen deficiency in the east field.</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Monitor north field for blight</p>
                      <p className="text-sm text-gray-600">Early signs detected. Consider preventative fungicide application.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {/* Disease Detection */}
          {activeTab === 'disease' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">Plant Disease Detection</h2>
              <p className="text-gray-600">Upload a photo of your plant to identify diseases and get treatment recommendations.</p>
              
              <div className="bg-white rounded-lg shadow-sm p-6">
                {!selectedImage ? (
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <Camera className="h-12 w-12 text-gray-400" />
                      <div>
                        <p className="text-gray-600 mb-2">Drag and drop an image here, or click to select</p>
                        <p className="text-xs text-gray-500">Supported formats: JPG, PNG (max 5MB)</p>
                      </div>
                      <label className="cursor-pointer">
                        <span className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 inline-block">
                          Select Image
                        </span>
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={handleImageUpload}
                        />
                      </label>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex flex-col md:flex-row md:space-x-6 space-y-6 md:space-y-0">
                      <div className="md:w-1/2">
                        <div className="relative rounded-lg overflow-hidden border border-gray-200" style={{height: '300px'}}>
                          <img 
                            src={selectedImage} 
                            alt="Selected plant" 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="mt-4 flex space-x-3">
                          <button 
                            onClick={resetAnalysis}
                            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                          >
                            Reset
                          </button>
                          <button 
                            onClick={analyzeImage}
                            disabled={isAnalyzing}
                            className={`flex-1 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex items-center justify-center ${isAnalyzing ? 'opacity-70 cursor-not-allowed' : ''}`}
                          >
                            {isAnalyzing ? 'Analyzing...' : 'Analyze Image'}
                          </button>
                        </div>
                      </div>
                      
                      <div className="md:w-1/2">
                        {isAnalyzing ? (
                          <div className="h-full flex items-center justify-center">
                            <div className="text-center">
                              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto"></div>
                              <p className="mt-4 text-gray-600">Analyzing your plant image...</p>
                              <p className="text-sm text-gray-500 mt-2">This may take a few moments</p>
                            </div>
                          </div>
                        ) : analysisResult ? (
                          <div className="space-y-4">
                            <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-md">
                              <div className="flex">
                                <div className="flex-shrink-0">
                                  <AlertTriangle className="h-5 w-5 text-red-500" />
                                </div>
                                <div className="ml-3">
                                  <h3 className="text-lg font-medium text-red-800">
                                    {analysisResult.disease} Detected
                                  </h3>
                                  <p className="text-sm text-red-700 mt-1">
                                    Confidence: {analysisResult.confidence.toFixed(1)}%
                                  </p>
                                </div>
                              </div>
                            </div>
                            
                            <div>
                              <h4 className="font-medium text-gray-800 mb-2">Recommended Actions:</h4>
                              <ul className="space-y-2">
                                {analysisResult.recommendations.map((rec, index) => (
                                  <li key={index} className="flex items-start">
                                    <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-green-100 text-green-800 text-xs mr-2 mt-0.5">
                                      {index + 1}
                                    </span>
                                    <span className="text-gray-700">{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                            
                            <div className="pt-4 border-t border-gray-200">
                              <button className="text-green-600 hover:text-green-700 text-sm font-medium">
                                View detailed treatment guide →
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="h-full flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg p-6">
                            <div className="text-center">
                              <BarChart3 className="h-12 w-12 text-gray-400 mx-auto" />
                              <p className="mt-4 text-gray-600">Click "Analyze Image" to detect diseases</p>
                              <p className="text-sm text-gray-500 mt-2">Results will appear here</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="bg-blue-50 rounded-lg p-4">
                <h3 className="text-lg font-medium text-blue-800 mb-2">How it works</h3>
                <p className="text-sm text-blue-700">
                  Our AI model analyzes your plant images to identify diseases with high accuracy. The system uses convolutional neural networks trained on thousands of plant images to detect early signs of common crop diseases.
                </p>
              </div>
            </div>
          )}

          {/* Soil Analysis */}
          {activeTab === 'soil' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-gray-800">Soil Analysis</h2>
                  <p className="text-gray-600">View soil health metrics and get fertilizer recommendations.</p>
                </div>
                <button 
                  onClick={refreshSoilData}
                  disabled={isFetchingSoil}
                  className={`px-4 py-2 rounded-md text-white ${isFetchingSoil ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'}`}
                >
                  {isFetchingSoil ? 'Refreshing...' : 'Refresh Data'}
                </button>
              </div>
              
              {soilError && (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-md">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <AlertTriangle className="h-5 w-5 text-yellow-400" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">{soilError}</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Moisture Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Soil Moisture</h3>
                    <Droplets className="h-5 w-5 text-blue-500" />
                  </div>
                  <div className="mt-2">
                    <div className="flex items-end justify-between mb-1">
                      <p className="text-3xl font-bold text-gray-800">{soilData ? soilData.moisture : 42}%</p>
                      <span className="text-sm text-green-600">Optimal</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${soilData ? soilData.moisture : 42}%` }}></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">Ideal range: 35-50%</p>
                  </div>
                </div>

                {/* pH Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Soil pH</h3>
                    <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-xs font-medium text-green-800">pH</span>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="flex items-end justify-between mb-1">
                      <p className="text-3xl font-bold text-gray-800">{soilData ? soilData.ph : 6.5}</p>
                      <span className="text-sm text-green-600">Slightly Acidic</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${((soilData ? soilData.ph : 6.5) / 14) * 100}%` }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>Acidic (0)</span>
                      <span>Neutral (7)</span>
                      <span>Alkaline (14)</span>
                    </div>
                  </div>
                </div>

                {/* Nutrients Card */}
                <div className="bg-white rounded-lg shadow-sm p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-gray-500">Nutrient Levels</h3>
                    <Leaf className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="space-y-3 mt-2">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Nitrogen (N)</span>
                        <span className="text-sm font-medium text-red-600">{soilData ? soilData.nitrogen : 'Low'}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: soilData && soilData.nitrogen === 'Medium' ? '60%' : soilData && soilData.nitrogen === 'High' ? '85%' : '30%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Phosphorus (P)</span>
                        <span className="text-sm font-medium text-yellow-600">{soilData ? soilData.phosphorus : 'Medium'}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm text-gray-600">Potassium (K)</span>
                        <span className="text-sm font-medium text-green-600">{soilData ? soilData.potassium : 'High'}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Organic Matter Card */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Organic Matter</h3>
                <div className="flex flex-col md:flex-row md:items-center md:space-x-8">
                  <div className="md:w-1/3">
                    <div className="relative pt-1">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="text-xs font-semibold inline-block text-green-600">
                            {soilData ? soilData.organicMatter.toFixed(1) : '2.1'}%
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-semibold inline-block text-green-600">
                            {soilData && soilData.organicMatter > 4 ? 'Excellent' : 
                             soilData && soilData.organicMatter > 2 ? 'Good' : 'Needs Improvement'}
                          </span>
                        </div>
                      </div>
                      <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                        <div style={{ width: `${Math.min((soilData ? soilData.organicMatter : 2.1) * 10, 100)}%` }} 
                             className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500">
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">
                      Organic matter is a key indicator of soil health. It improves soil structure, water retention, and nutrient availability.
                    </p>
                  </div>
                  <div className="md:w-2/3 mt-6 md:mt-0">
                    <h4 className="font-medium text-gray-800 mb-2">What This Means</h4>
                    <p className="text-sm text-gray-700 mb-4">
                      {soilData && soilData.organicMatter > 4 ? 
                        'Your soil has excellent organic matter content, indicating good soil health and fertility. This supports strong microbial activity and nutrient cycling.' : 
                      soilData && soilData.organicMatter > 2 ? 
                        'Your soil has moderate organic matter content. While acceptable, increasing organic matter would improve soil structure and fertility.' : 
                        'Your soil has low organic matter content. Adding compost, cover crops, or other organic amendments would significantly improve soil health and crop productivity.'}
                    </p>
                    <div className="bg-green-50 p-3 rounded-md">
                      <h5 className="text-sm font-medium text-green-800 mb-1">Improvement Strategies</h5>
                      <ul className="text-xs text-green-700 space-y-1 list-disc pl-4">
                        <li>Add compost or well-rotted manure annually</li>
                        <li>Implement cover crops in rotation</li>
                        <li>Practice minimal tillage to preserve soil structure</li>
                        <li>Leave crop residues in the field when possible</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Fertilizer Recommendations</h3>
                <div className="space-y-4">
                  <p className="text-gray-700">{soilData ? soilData.recommendations : 'Consider adding nitrogen-rich fertilizer to improve soil health.'}</p>
                  
                  <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertTriangle className="h-5 w-5 text-yellow-400" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-yellow-700">
                          Apply fertilizer in the early morning or late evening for best results. Avoid application before heavy rainfall.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Fertilizer Type
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Application Rate
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Frequency
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                            Nitrogen-rich organic compost
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            2-3 kg per 10 sq. meters
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            Every 3-4 weeks
                          </td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-800">
                            NPK 10-5-5 blend
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            1 kg per 20 sq. meters
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            Once per growing season
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Soil Health History */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">Soil Health History</h3>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                      Last Month
                    </button>
                    <button className="px-3 py-1 text-sm bg-green-50 border border-green-200 rounded-md text-green-700">
                      Last 3 Months
                    </button>
                    <button className="px-3 py-1 text-sm border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50">
                      Last Year
                    </button>
                  </div>
                </div>
                
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Soil health trend chart would appear here</p>
                </div>
              </div>
            </div>
          )}

          {/* Weather Forecast */}
          {activeTab === 'weather' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-800">Weather Forecast</h2>
              <p className="text-gray-600">View current conditions and forecast to plan your farming activities.</p>
              
              {/* Current Weather */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex flex-col md:flex-row md:items-center md:space-x-8">
                  <div className="flex-1">
                    <div className="flex items-center space-x-4">
                      <div className="bg-blue-100 p-3 rounded-full">
                        <CloudRain className="h-8 w-8 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-gray-800">Today's Weather</h3>
                        <p className="text-gray-600">
                          {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })} • 
                          {weatherData && weatherData.city ? ` ${weatherData.city.name}` : ' Your Farm Location'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Temperature</p>
                        <p className="text-2xl font-bold text-gray-800">
                          {currentWeather ? `${currentWeather.temp}°C` : `${mockWeatherData.temperature}°C`}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Humidity</p>
                        <p className="text-2xl font-bold text-gray-800">
                          {currentWeather ? `${currentWeather.humidity}%` : `${mockWeatherData.humidity}%`}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Wind</p>
                        <p className="text-2xl font-bold text-gray-800">
                          {currentWeather ? `${currentWeather.wind} km/h` : '12 km/h'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Rainfall</p>
                        <p className="text-2xl font-bold text-gray-800">
                          {mockWeatherData.rainfall} mm
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 md:mt-0 md:w-1/3 bg-blue-50 rounded-lg p-4">
                    <h4 className="font-medium text-blue-800 mb-2">Weather Impact</h4>
                    <p className="text-sm text-blue-700 mb-4">
                      Current conditions are favorable for field work. No significant weather risks for the next 24 hours.
                    </p>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <p className="text-xs text-green-700">Optimal for spraying</p>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <p className="text-xs text-green-700">Good for harvesting</p>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                      <p className="text-xs text-yellow-700">Moderate for irrigation</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* 5-Day Forecast */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">5-Day Forecast</h3>
                
                {weatherError && (
                  <div className="mb-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                    <div className="flex">
                      <div className="flex-shrink-0">
                        <AlertTriangle className="h-5 w-5 text-yellow-400" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm text-yellow-700">{weatherError}</p>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                  {formattedForecast.length > 0 ? (
                    formattedForecast.map((day, index) => (
                      <div key={index} className={`p-4 rounded-lg ${index === 0 ? 'bg-blue-50 border border-blue-100' : 'border border-gray-200'}`}>
                        <p className={`font-medium ${index === 0 ? 'text-blue-800' : 'text-gray-800'}`}>{day.day}</p>
                        <div className="my-3 flex justify-center">
                          {day.icon === 'sun' && <div className="h-10 w-10 text-yellow-500">☀️</div>}
                          {day.icon === 'cloud' && <div className="h-10 w-10 text-gray-500">☁️</div>}
                          {day.icon === 'cloud-rain' && <div className="h-10 w-10 text-blue-500">🌧️</div>}
                        </div>
                        <p className="text-center text-2xl font-bold text-gray-800">{day.temp}°C</p>
                        {day.condition && (
                          <div className="mt-2 pt-2 border-t border-gray-200">
                            <p className="text-xs text-center text-blue-600">{day.condition}</p>
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    // Fallback to mock data if no forecast data is available
                    mockWeatherData.forecast.map((day, index) => (
                      <div key={index} className={`p-4 rounded-lg ${index === 0 ? 'bg-blue-50 border border-blue-100' : 'border border-gray-200'}`}>
                        <p className={`font-medium ${index === 0 ? 'text-blue-800' : 'text-gray-800'}`}>{day.day}</p>
                        <div className="my-3 flex justify-center">
                          {day.icon === 'sun' && <div className="h-10 w-10 text-yellow-500">☀️</div>}
                          {day.icon === 'cloud' && <div className="h-10 w-10 text-gray-500">☁️</div>}
                          {day.icon === 'cloud-rain' && <div className="h-10 w-10 text-blue-500">🌧️</div>}
                        </div>
                        <p className="text-center text-2xl font-bold text-gray-800">{day.temp}°C</p>
                        {index === 1 && (
                          <div className="mt-2 pt-2 border-t border-gray-200">
                            <p className="text-xs text-center text-blue-600">Rain expected</p>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              {/* Precipitation Forecast */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Precipitation Forecast</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <p className="text-gray-500">Precipitation chart would appear here</p>
                </div>
                <div className="mt-4 bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <AlertTriangle className="h-5 w-5 text-yellow-400" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-yellow-800">Weather Alert</h3>
                      <div className="mt-2 text-sm text-yellow-700">
                        <p>Heavy rainfall expected in 48 hours. Consider completing any field operations that require dry conditions before then.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Weather-Based Recommendations */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Weather-Based Recommendations</h3>
                <ul className="space-y-4">
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-green-800 text-xs">1</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Complete harvesting within 48 hours</p>
                      <p className="text-sm text-gray-600">Heavy rainfall is expected after that, which could delay harvest operations.</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-green-800 text-xs">2</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Delay irrigation</p>
                      <p className="text-sm text-gray-600">Natural rainfall will provide sufficient moisture for the next 3-4 days.</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-green-800 text-xs">3</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">Apply fungicide preventatively</p>
                      <p className="text-sm text-gray-600">The upcoming humid conditions increase the risk of fungal diseases.</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;