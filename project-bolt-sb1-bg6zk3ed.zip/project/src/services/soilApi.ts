// Soil API Service
// This service handles fetching soil data from the Soil Grid API

// Base URL for the SoilGrids API
const SOIL_GRID_API_BASE_URL = 'https://rest.isric.org/soilgrids/v2.0/properties/query';

// Types for soil data
export interface SoilData {
  moisture: number;
  ph: number;
  nitrogen: string;
  phosphorus: string;
  potassium: string;
  organicMatter: number;
  recommendations: string;
}

export interface SoilLocation {
  lat: number;
  lon: number;
}

// Function to fetch soil data from the API
export const fetchSoilData = async (location: SoilLocation): Promise<SoilData> => {
  try {
    // Make API request to SoilGrids
    const response = await fetch(`${SOIL_GRID_API_BASE_URL}?lat=${location.lat}&lon=${location.lon}`);
    
    if (!response.ok) {
      throw new Error(`Soil API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Process the API response
    return processSoilData(data);
  } catch (error) {
    console.error('Error fetching soil data:', error);
    // Return mock data if API fails
    return getMockSoilData();
  }
};

// Process the API response into our application's format
const processSoilData = (apiData: any): SoilData => {
  // In a real implementation, we would extract the relevant data from the API response
  // For this example, we'll use some of the data and supplement with mock data
  
  // Extract organic carbon content (as a proxy for organic matter)
  let organicMatter = 2.5; // Default value
  
  try {
    if (apiData.properties.soc) {
      // SoilGrids returns soil organic carbon in g/kg
      // We'll use the mean value from the top layer (0-5cm)
      organicMatter = apiData.properties.soc.values[0].mean / 10; // Convert to percentage
    }
  } catch (e) {
    console.warn('Could not extract organic matter data', e);
  }
  
  // Generate recommendations based on the data
  const recommendations = generateRecommendations(organicMatter);
  
  // Return processed data combined with mock data for fields not available in the API
  return {
    moisture: calculateMoisture(apiData),
    ph: 6.5, // SoilGrids doesn't provide pH directly, using mock value
    nitrogen: determineNutrientLevel(organicMatter, 'nitrogen'),
    phosphorus: 'Medium', // Mock value
    potassium: 'High', // Mock value
    organicMatter,
    recommendations
  };
};

// Calculate estimated soil moisture based on soil properties
const calculateMoisture = (apiData: any): number => {
  // In a real implementation, we would use clay/sand content to estimate moisture
  // For this example, we'll return a reasonable value
  try {
    // Use clay content as a factor in moisture calculation
    // Higher clay content generally means higher water retention
    if (apiData.properties.clay && apiData.properties.clay.values) {
      const clayContent = apiData.properties.clay.values[0].mean;
      // Simple formula: higher clay = higher moisture (within reasonable range)
      return Math.min(Math.max(30 + (clayContent / 10), 30), 60);
    }
  } catch (e) {
    console.warn('Could not calculate moisture from soil data', e);
  }
  
  // Default moisture value if calculation fails
  return 42;
};

// Determine nutrient level based on organic matter content
const determineNutrientLevel = (organicMatter: number, nutrient: string): string => {
  // Simple logic to determine nutrient levels
  // In a real app, this would be more sophisticated
  if (nutrient === 'nitrogen') {
    if (organicMatter < 2) return 'Low';
    if (organicMatter < 4) return 'Medium';
    return 'High';
  }
  
  // Default to medium for other nutrients
  return 'Medium';
};

// Generate recommendations based on soil data
const generateRecommendations = (organicMatter: number): string => {
  if (organicMatter < 2) {
    return 'Consider adding nitrogen-rich fertilizer and organic matter to improve soil health. Implement cover crops to build soil structure.';
  } else if (organicMatter < 4) {
    return 'Soil has moderate organic matter. Apply balanced fertilizer and continue adding compost to maintain soil health.';
  } else {
    return 'Soil has good organic matter content. Maintain current practices and monitor nutrient levels to prevent excess.';
  }
};

// Mock data for fallback
export const getMockSoilData = (): SoilData => {
  return {
    moisture: 42,
    ph: 6.5,
    nitrogen: 'Low',
    phosphorus: 'Medium',
    potassium: 'High',
    organicMatter: 2.1,
    recommendations: 'Consider adding nitrogen-rich fertilizer to improve soil health. Implement cover crops to build soil structure.'
  };
};